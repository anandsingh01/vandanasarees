@extends('layouts.web')
<?php
session_start();
$getCommonSetting = getCommonSetting();
?>
@section('css')
    <style>
        .sticky_header{
            position:unset;
        }
        .watch_header + main {
            margin-top: 0px;
        }
        .item.slick-slide{
            margin:0;
        }

    </style>
    <style>
        .hero {
            background: #e1e3de;
            padding: calc(8rem - 30px) 0 8rem 0;
        }
        .intro-excerpt {
            padding: 5em 0;
        }
        .why-choose-section {
            padding: 7rem 0;
        }
    </style>
@stop
@section('body')
    <?php
    $get_cart = get_cart();
    $get_count = json_decode($get_cart);
    $getAllCart = getCartProducts();
    ?>

    <main class="main">
        <div class="hero">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-lg-5">
                        <div class="intro-excerpt">
                            <h1>About Us</h1>
                            <p class="mb-4">Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique.</p>
                            <p><a href="" class="btn btn-secondary me-2">Shop Now</a><a href="#" class="btn btn-white-outline">Explore</a></p>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="hero-img-wrap">
                            <img src="https://themewagon.github.io/furni/images/couch.png" class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="why-choose-section">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-lg-6">
                        <h2 class="section-title">Why Choose Us</h2>
                        <p>Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique.</p>

                        <div class="row my-5">
                            <div class="col-6 col-md-6">
                                <div class="feature">
                                    <div class="icon">
                                        <img src="https://themewagon.github.io/furni/images/truck.svg" alt="Image" class="imf-fluid">
                                    </div>
                                    <h3>Fast &amp; Free Shipping</h3>
                                    <p>Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate.</p>
                                </div>
                            </div>

                            <div class="col-6 col-md-6">
                                <div class="feature">
                                    <div class="icon">
                                        <img src="https://themewagon.github.io/furni/images/bag.svg" alt="Image" class="imf-fluid">
                                    </div>
                                    <h3>Easy to Shop</h3>
                                    <p>Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate.</p>
                                </div>
                            </div>

                            <div class="col-6 col-md-6">
                                <div class="feature">
                                    <div class="icon">
                                        <img src="https://themewagon.github.io/furni/images/support.svg" alt="Image" class="imf-fluid">
                                    </div>
                                    <h3>24/7 Support</h3>
                                    <p>Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate.</p>
                                </div>
                            </div>

                            <div class="col-6 col-md-6">
                                <div class="feature">
                                    <div class="icon">
                                        <img src="https://themewagon.github.io/furni/images/return.svg" alt="Image" class="imf-fluid">
                                    </div>
                                    <h3>Hassle Free Returns</h3>
                                    <p>Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate.</p>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-5">
                        <div class="img-wrap">
                            <img src="https://themewagon.github.io/furni/images/why-choose-us-img.jpg" alt="Image" class="img-fluid">
                        </div>
                    </div>

                </div>
            </div>
        </div>
{{--        <div class="" style="background-image: url('assets/images/backgrounds/login-bg.jpg')">--}}
{{--            <div class="container"  id="privacy_policy">--}}
{{--                <div class="row">--}}
{{--                    <br>--}}
{{--                    <div class="col-md-12">--}}
{{--                        <?php--}}
{{--                        echo $getCommonSetting->about_us_content;--}}
{{--                        ?>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div><!-- End .container -->--}}
{{--        </div><!-- End .login-page section-bg -->--}}
    </main>

@stop
@section('js')

@stop
