@extends('layouts.web')
<?php
session_start();
?>
@section('css')
<style>
    .container {
        max-width: 90%;
    }
    .quantity_input input {
        width: 49%;
        border: none;
        padding: 0px;
        outline: none;
        font-size: 18px;
        font-weight: 600;
        text-align: center;
    }

    .cart_section{
        position: relative;
    }
    .home_watch .custom_btn {
        padding: 10px 20px;
    }
    .sticky_header{
        position:unset;
    }
    .watch_header + main {
        margin-top: 0px;
    }
    section.body_yield_div {
        background: #fbfbfb;
    }
    .d-for-mobile{
        display:none;
    }
    /*.d-for-desk{*/
    /*    display: block;*/
    /*}*/
    .section.content-start {
        padding: 5em 0;
    }
    @media (max-width: 767px) {
        section.cart_section.sec_ptb_140.clearfix {
            background: #fff;
        }
        .checkout_step a {
            font-size: 17px;
            padding: 5px 30px;
        }
        .cart_table .table {
            width: 100%;
        }
        .cart_product .item_image {
            width: 66px;
            margin-right: 10px;
        }
        .d-for-mobile{
            display:block;
        }
        .d-for-desk{
            display: none;
        }
        .quantity_input input{
            width:10%;
        }
        .quantity_input{
            height:35px;
        }
        .quantity_input.d-for-mobile form {
            width: 100%;
        }
        .quantity_input span {
            color: #ced9df;
            line-height: 1;
            cursor: pointer;
            font-size: 20px;
            margin: 0px 10px;
            transition: 0.6s cubic-bezier(0.25, 1, 0.5, 1);
        }
        .cart_product .item_type p,  .item_type p,  {
            margin-bottom: 5px;
            font-size: 16px;
        }
        .cart_product span {
            font-size: 16px;
        }
    }
</style>
@stop
@section('body')
    <?php
    $get_cart = get_cart();
    $get_count = json_decode($get_cart);
    $getAllCart = getCartProducts();
    ?>


    <div class="card">
        <style>
            .title{
                margin-bottom: 5vh;
            }
            .card{
                margin: auto;
                max-width: 950px;
                width: 90%;
                box-shadow: 0 6px 20px 0 rgba(0, 0, 0, 0.19);
                border-radius: 1rem;
                border: transparent;
            }
            @media(max-width:767px){
                .card{
                    margin: 3vh auto;
                }
            }
            .cart{
                background-color: #fff;
                padding: 4vh 5vh;
                border-bottom-left-radius: 1rem;
                border-top-left-radius: 1rem;
            }
            @media(max-width:767px){
                .cart{
                    padding: 4vh;
                    border-bottom-left-radius: unset;
                    border-top-right-radius: 1rem;
                }
            }
            .summary{
                background-color: #ddd;
                border-top-right-radius: 1rem;
                border-bottom-right-radius: 1rem;
                padding: 4vh;
                color: rgb(65, 65, 65);
            }
            @media(max-width:767px){
                .summary{
                    border-top-right-radius: unset;
                    border-bottom-left-radius: 1rem;
                }
            }
            .summary .col-2{
                padding: 0;
            }
            .summary .col-10
            {
                padding: 0;
            }
            .card .row{
                margin: 0;
            }
            .title b{
                font-size: 1.5rem;
            }
            .card .main{
                margin: 0;
                padding: 2vh 0;
                width: 100%;
            }
            .card .col-2, .col{
                padding: 0 1vh;
            }
            .card a{
                padding: 0 1vh;
            }
            .close{
                margin-left: auto;
                font-size: 0.7rem;
            }
            .card img{
                width: 3.5rem;
            }
            .card .back-to-shop{
                margin-top: 4.5rem;
            }
            .card h5{
                margin-top: 4vh;
            }
            .card hr{
                margin-top: 1.25rem;
            }
            .card form{
                padding: 2vh 0;
            }
            .card select{
                border: 1px solid rgba(0, 0, 0, 0.137);
                padding: 1.5vh 1vh;
                margin-bottom: 4vh;
                outline: none;
                width: 100%;
                background-color: rgb(247, 247, 247);
            }
            .card input{
                border: 1px solid rgba(0, 0, 0, 0.137);
                padding: 1vh;
                margin-bottom: 4vh;
                outline: none;
                width: 100%;
                background-color: rgb(247, 247, 247);
            }
            input:focus::-webkit-input-placeholder
            {
                color:transparent;
            }
            .btn{
                background-color: #000;
                border-color: #000;
                color: white;
                width: 100%;
                font-size: 0.7rem;
                margin-top: 4vh;
                padding: 1vh;
                border-radius: 0;
            }
            .card .btn:focus{
                box-shadow: none;
                outline: none;
                box-shadow: none;
                color: white;
                -webkit-box-shadow: none;
                -webkit-user-select: none;
                transition: none;
            }
            .card .btn:hover{
                color: white;
            }

            #code{
                background-image: linear-gradient(to left, rgba(255, 255, 255, 0.253) , rgba(255, 255, 255, 0.185)), url("https://img.icons8.com/small/16/000000/long-arrow-right.png");
                background-repeat: no-repeat;
                background-position-x: 95%;
                background-position-y: center;
            }
        </style>

        <div class="row">
            <div class="col-md-8 cart">
                <div class="title">
                    <div class="row">
                        <div class="col"><h4><b>Shopping Cart</b></h4></div>
                        <div class="col align-self-center text-right text-muted">{{ $getAllCart->count() }} items</div>
                    </div>
                </div>

                @foreach($getAllCart as $cartItem)
                    <div class="row border-top border-bottom">
                        <div class="row main align-items-center">
                            <div class="col-2">
                                <img class="img-fluid" src="{{ asset($cartItem->getProducts->photo) }}">
                            </div>
                            <div class="col">
                                <div class="row text-muted">{{ $cartItem->getProducts->category->category_name ?? 'Category' }}</div>
                                <div class="row">{{ $cartItem->getProducts->title ?? 'Product Name' }}</div>
                            </div>
                            <div class="col">
                                <a href="#" class="update-quantity" data-action="decrement" data-cartid="{{ $cartItem->id }}">-</a>
                                <a href="#" class="border">{{ $cartItem->cartqty }}</a>
                                <a href="#" class="update-quantity" data-action="increment" data-cartid="{{ $cartItem->id }}">+</a>
                            </div>
                            <div class="col">Rs. {{ $cartItem->subtotal }} <span class="close remove-item" data-cartid="{{ $cartItem->id }}">&times;</span></div>
                        </div>
                    </div>
                @endforeach

                <div class="back-to-shop"><a href="{{ url('/shop') }}">&leftarrow;</a><span class="text-muted">Back to shop</span></div>
            </div>

            <div class="col-md-4 summary">
                <div><h5><b>Summary</b></h5></div>
                <hr>
                <div class="row">
                    <div class="col" style="padding-left:0;">ITEMS {{ $getAllCart->count() }}</div>
                    <div class="col text-right">Rs. {{ $getAllCart->sum('subtotal') }}</div>
                </div>
                <form>
                    <p>SHIPPING</p>
                    <select><option class="text-muted">Standard-Delivery - Rs. 50.00</option></select>
                    <p>GIVE CODE</p>
                    <input id="code" placeholder="Enter your code">
                </form>
                <div class="row" style="border-top: 1px solid rgba(0,0,0,.1); padding: 2vh 0;">
                    <div class="col">TOTAL PRICE</div>
                    <div class="col text-right">Rs. {{ $getAllCart->sum('subtotal') + 50 }}</div>
                </div>
                <button class="btn">CHECKOUT</button>
            </div>
        </div>
    </div>

{{--    <section class="cart_section sec_ptb_140 clearfix">--}}
{{--        <div class="container">--}}
{{--            <ul class="checkout_step ul_li clearfix">--}}
{{--                <li class="active"><a href="{{url('/checkout/cart')}}"><span>01.</span> Shopping Cart</a></li>--}}
{{--                <li><a href="javascript:void(0)"><span>02.</span> Checkout</a></li>--}}
{{--                <li><a href="javascript:void(0)"><span>03.</span> Order Completed</a></li>--}}
{{--            </ul>--}}

{{--            <div class="row">--}}
{{--                <div class="col-md-9">--}}
{{--                    <div class="cart_table mb_50">--}}
{{--                        <table class="table">--}}
{{--                            <thead class="text-uppercase">--}}
{{--                            <tr>--}}
{{--                                <th>Product Name</th>--}}
{{--                                <th>Price</th>--}}
{{--                                <th class="d-for-desk">Quantity</th>--}}
{{--                                <th class="d-for-desk">Total Price</th>--}}
{{--                            </tr>--}}
{{--                            </thead>--}}
{{--                            <tbody>--}}
{{--                            @forelse($getAllCart as $getAllCarts)--}}
{{--                                <tr>--}}
{{--                                    <td>--}}
{{--                                        <div class="cart_product">--}}
{{--                                            <button type="button" class="remove_btn removebtn text-black" onclick="deleteConfirmation2({{$getAllCarts->id}})" data-cartid="{{$getAllCarts->id}}">--}}
{{--                                                <i class="fal fa-times"></i>--}}
{{--                                            </button>--}}
{{--                                            <div class="item_image">--}}
{{--                                                <img src="{{asset($getAllCarts->getProducts->photo)}}" alt="image_not_found">--}}
{{--                                            </div>--}}
{{--                                            <div class="item_content">--}}
{{--                                                <h4 class="item_title"> {{$getAllCarts->getProducts->title ?? ''}}</h4>--}}
{{--                                                <span class="item_type">--}}

{{--                                                    <?php--}}
{{--                                                    $getcategory = \App\Models\Category::where('id',$getAllCarts->getProducts->section_id)->first();--}}
{{--                                                    ?>--}}

{{--                                                    <p> {{$getcategory->category_name ?? ''}}</p>--}}

{{--                                                    @if(!empty($getAllCarts->getColor->attribute_value))--}}

{{--                                                    <?php--}}
{{--                                                    $getColor = \App\Models\AttributeValue::where('id',$getAllCarts->getColor->attribute_value)->first();--}}
{{--                                                    ?>--}}

{{--                                                    <p>Color : @if(!empty($getAllCarts->getColor->image))--}}
{{--                                                                <img src="{{asset($getAllCarts->getColor->image)}}" style="--}}
{{--                                         width:10px;--}}
{{--                                         height:10px;--}}
{{--                                         border-radius: 50%;--}}
{{--                                         object-fit: cover;">--}}
{{--                                                        @else--}}
{{--                                                                   Default--}}
{{--                                                                   @endif--}}
{{--                                                    </p>--}}
{{--                                                    @else--}}

{{--                                                        <p>Color :  <img src="https://dictionaryblog.cambridge.org/wp-content/uploads/2020/07/black-and-white-1.png?w=300"--}}
{{--                                                        style=" width:10px;--}}
{{--                                         height:10px;--}}
{{--                                         border-radius: 50%;--}}
{{--                                         object-fit: cover;" >--}}
{{--                                                        </p>--}}

{{--                                                   @endif--}}
{{--                                                </span>--}}
{{--                                            </div>--}}

{{--                                            <br>--}}


{{--                                        </div>--}}

{{--                                        <div class="quantity_input d-for-mobile ">--}}
{{--                                            <form action="#">--}}
{{--                                                <span class="input_number_decrement">–</span>--}}
{{--                                                <input class="input_number qty2" type="text"--}}
{{--                                                       id="quantityInput2{{$getAllCarts->getProducts->id}}"--}}
{{--                                                       value="{{$getAllCarts->cartqty}}"--}}
{{--                                                       data-cartid="{{$getAllCarts->id}}"--}}
{{--                                                       max="3" min="1"--}}
{{--                                                >--}}
{{--                                                <span class="input_number_increment">+</span>--}}
{{--                                            </form>--}}
{{--                                        </div>--}}
{{--                                    </td>--}}
{{--                                    <td class=" ">--}}
{{--                                        <span class="price_text">Rs. {{$getAllCarts->per_piece_price}}</span>--}}
{{--                                    </td>--}}
{{--                                    <td class="d-for-desk">--}}

{{--                                        <div class="quantity_input ">--}}
{{--                                            <form action="#">--}}
{{--                                                <span class="input_number_decrement">–</span>--}}
{{--                                                <input class="input_number qty2" type="text"--}}
{{--                                                       id="quantityInput2{{$getAllCarts->getProducts->id}}"--}}
{{--                                                       value="{{$getAllCarts->cartqty}}"--}}
{{--                                                       data-cartid="{{$getAllCarts->id}}"--}}
{{--                                                       max="3" min="1"--}}
{{--                                                >--}}
{{--                                                <span class="input_number_increment">+</span>--}}
{{--                                            </form>--}}
{{--                                        </div>--}}
{{--                                    </td>--}}
{{--                                    <td class="d-for-desk"><span class="total_price{{$getAllCarts->id}}" id="total_price{{$getAllCarts->id}}">Rs. {{$getAllCarts->subtotal}}</span></td>--}}
{{--                                </tr>--}}

{{--                            @empty--}}
{{--                            @endforelse--}}
{{--                            </tbody>--}}
{{--                        </table>--}}
{{--                    </div>--}}
{{--                    <div class="coupon_wrap mb_50">--}}
{{--                        <div class="row justify-content-lg-between">--}}
{{--                            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">--}}
{{--                                <div class="coupon_form">--}}
{{--                                    <div class="form_item mb-0">--}}
{{--                                        <input type="text" class="coupon" id="couponCode" placeholder="Coupon Code">--}}
{{--                                    </div>--}}
{{--                                    <button type="submit" id="applyCouponBtn" class="custom_btn bg_danger text-uppercase">Apply Coupon</button>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                            <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12">--}}
{{--                                <div class="cart_update_btn">--}}
{{--                                    <button type="button" class="custom_btn bg_secondary text-uppercase">Update Cart</button>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}

{{--                </div>--}}
{{--                <div class="col-md-3">--}}
{{--                    <div class="row justify-content-lg-end">--}}
{{--                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">--}}
{{--                            <div class="cart_pricing_table pt-0 text-uppercase" data-bg-color="#f2f3f5">--}}
{{--                                <h3 class="table_title text-center" data-bg-color="#ededed">Cart Total</h3>--}}
{{--                                <ul class="ul_li_block clearfix">--}}
{{--                                    <li><span>Subtotal</span> <span id="subtotalamount">Rs. {{$getsubtotal}}</span></li>--}}
{{--                                    <li><span>Total</span> <span id="final_amount">Rs. {{$getsubtotal}}</span></li>--}}
{{--                                </ul>--}}
{{--                                @if(Auth::check())--}}
{{--                                    <a href="{{url('checkout')}}" class="custom_btn bg_success">Proceed to Checkout</a>--}}
{{--                                @else--}}
{{--                                    <a href="{{url('/guest-checkout')}}" class="custom_btn bg_success">Proceed to Checkout</a>--}}
{{--                                @endif--}}

{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}

{{--        </div>--}}
{{--    </section>--}}
@stop
@section('js')

    <script>
        function deleteConfirmation2(id) {
            $.ajax({
                type: 'get',
                url: "{{url('delete-from-cart/')}}" + id,
                dataType: 'JSON',
                success: function (results) {

                    if (results.success === true) {
                        swal("Done!", results.message, "success");
                        // location.reload();
                        location.reload();
                    } else {
                        swal("Error!", results.message, "error");
                        // location.reload();
                    }
                }
            });
        }
    </script>
    <!-- Update cart start--->
    <script>
        $(document).ready(function () {
            $('.qty2').on('change', function () {
                const cartId = $(this).data('cartid');
                const quantity = $(this).closest('tr').find('.qty2').val();

                if(quantity == 0){
                    // alert('abc');
                    // return false;
                    $.ajax({
                        type: 'get',
                        url: "{{url('/delete-from-cart')}}" + '/' +cartId,
                        dataType: 'JSON',
                        success: function (results) {

                            if (results.success === true) {
                                swal("Done!", results.message, "success");
                                location.reload();
                                // $('#body-id').load('#body-id');
                            } else {
                                swal("Error!", results.message, "error");
                                location.reload();
                            }
                        }
                    });
                }

                // Send AJAX request to update the cart
                $.ajax({
                    url: '{{url('updateCart')}}',
                    method: 'POST',
                    data: {
                        cartId: cartId,
                        quantity: quantity,
                        // Add other cart data fields if needed
                    },
                    success: function (response) {

                        const updatedSubtotal = response.updatedSubtotal;

                        const sum_of_subtotal = response.sum_of_subtotal;

                        $('#total_price' + cartId).html('Rs. ' + updatedSubtotal);

                        $('#subtotalamount').text('Rs. ' + sum_of_subtotal);

                        $('#final_amount').text('Rs. ' + sum_of_subtotal);

                    },
                    error: function (xhr, status, error) {
                        // Handle error if needed
                    }
                });
            });
        });
    </script>
    <!-- Update cart end--->

    <!-- Delete cart start--->
    <script>
        function deleteConfirmation2(id) {
            $.ajax({
                type: 'get',
                url: "{{url('/delete-from-cart')}}/" + id,
                dataType: 'JSON',
                success: function (results) {

                    if (results.success === true) {
                        swal("Done!", results.message, "success");
                        // location.reload();
                        location.reload();
                    } else {
                        swal("Error!", results.message, "error");
                        // location.reload();
                    }
                }
            });
        }
    </script>
    <!-- Delete cart start--->

    <!-- Apply coupon start--->
    <script>
        $(document).ready(function() {
            const applyCouponBtn = $('#applyCouponBtn');
            const couponCodeInput = $('#couponCode');

            applyCouponBtn.click(function(event) {
                event.preventDefault();
                const couponCode = couponCodeInput.val();

                // Make an AJAX request to apply the coupon code
                $.ajax({
                    url: '{{ route('cart.apply_coupon') }}',
                    type: 'POST',
                    data: { coupon_code: couponCode },
                    dataType: 'json',
                    success: function(response) {

                        // Update the cart total with the discounted total
                        const summaryTotal = $('.summary-total td:last-child');
                        summaryTotal.text('$ ' + response.discounted_total.toFixed(2));
                        $('.final_amount').html('$ ' + response.discounted_total.toFixed(2));
                        $('#body-id').load('#body-id');
                    },
                    error: function(xhr) {
                        console.log('Error:', xhr.responseText);
                    }
                });
            });
        });

    </script>
    <!-- Apply coupon stop--->


    <script>
        $(document).ready(function() {
            $('.address-checkbox').on('change', function() {
                $('.address-checkbox').not(this).prop('checked', false);
            });
            if(screen.width > 768){

            }else{
                //alert("hello");

                $(".tablezoom").css("zoom", "0.7");
            }

        });
    </script>

    <script>
        $(document).ready(function () {

            $('#checkoutBtn').prop('disabled', true);

            {{--const isAuthenticated = {!! json_encode(Auth::check()) !!};--}}
            {{--@if(Auth::check())--}}
            {{--const addresses = isAuthenticated ? {!! json_encode($addresses) !!} : [];--}}
            {{--@endif--}}

            const $addressRadioButtons = $('input[name="selected_address"]');

            const $formFields = {
                first_name: $('input[name="first_name"]'),
                last_name: $('input[name="last_name"]'),
                country: $('input[name="country"]'),
                address_1: $('input[name="address_1"]'),
                address_2: $('input[name="address_2"]'),
                city: $('input[name="city"]'),
                state: $('input[name="state"]'),
                pincode: $('input[name="pincode"]'),
                phone: $('input[name="phone"]'),
                email: $('input[name="email"]')
            };

            function showSavedAddresses() {
                $savedAddresses.show();
                $manualForm.hide();
            }

            function showManualForm() {
                $savedAddresses.hide();
                $manualForm.show();
            }

            function populateAddressFields(address) {
                for (const field in $formFields) {
                    $formFields[field].val(address[field]);
                }
            }

            function clearFormFields() {
                for (const field in $formFields) {
                    $formFields[field].val('');
                }
            }

            $addressRadioButtons.on('change', function () {
                // alert('abc');
                // return false;
                const selectedAddressId = $(this).val();
                // alert(selectedAddressId);
                // return false;
                if (selectedAddressId !== '') {
                    const selectedAddress = addresses.find(address => address.id === parseInt(selectedAddressId));
                    populateAddressFields(selectedAddress);
                    // $('#checkoutBtn').
                } else {
                    clearFormFields();
                    $shippingOptions.empty();
                    $selectedCourier.html('');
                }
            });


            (isAuthenticated && addresses.length > 0) ? showSavedAddresses() : showManualForm();
        });

    </script>

    <script>


        $(document).ready(function() {

            {{--const isAuthenticated = {!! json_encode(Auth::check()) !!};--}}
            {{--@if(Auth::check())--}}
            {{--const addresses = isAuthenticated ? {!! json_encode($addresses) !!} : [];--}}
            {{--@endif--}}

            const $addressRadioButtons = $('input[name="selected_address"]');
            const $checkoutBtn = $('#checkoutBtn');
            // const $checkoutBtn = $('#checkoutBtn');
            let selectedAddressId; // Initialize the variable here

            $addressRadioButtons.on('change', function() {
                selectedAddressId = $(this).val(); // Update the variable when a radio button is changed

                if (selectedAddressId) {
                    // Update the "PROCEED TO CHECKOUT" button's data-addressid attribute
                    $checkoutBtn.attr('data-addressid', selectedAddressId);
                }
            });


            var selectedValue = '';
            $('#same_billing').change(function() {
                if ($(this).is(':checked')) {
                    // Set the value to "1" when checked
                    selectedValue = '1';
                } else {
                    // Remove the value when unchecked
                    selectedValue = '0';
                }
            })

            // return false;

            // Event listener for the "PROCEED TO CHECKOUT" button click
            $checkoutBtn.on('click', function(event) {
                event.preventDefault(); // Prevent the default link behavior

                if(isAuthenticated){
                    if (selectedAddressId) {
                        window.location.href = `{{ url('checkout') }}?addressid=${selectedAddressId}&sameBilling=${selectedValue}`;
                    }else{
                        swal({
                            title: "Please select address",
                            icon: "warning",
                            buttons: "OK",
                        });
                        // alert('Please select address');
                    }
                } else {



                    $("#submithit").click()

                    //$('#newAddressForm2').submit();
                }
            });
        });
    </script>













{{--    <script>--}}
{{--        $(document).ready(function () {--}}
{{--            $('.qty2').on('change', function () {--}}
{{--                const cartId = $(this).data('cartid');--}}
{{--                const quantity = $(this).closest('tr').find('.qty2').val();--}}


{{--                if(quantity == 0){--}}
{{--                    $.ajax({--}}
{{--                        type: 'get',--}}
{{--                        url: "{{url('/delete-from-cart')}}/" + cartId,--}}
{{--                        dataType: 'JSON',--}}
{{--                        success: function (results) {--}}

{{--                            if (results.success === true) {--}}
{{--                                swal("Done!", results.message, "success");--}}
{{--                                location.reload();--}}
{{--                                // $('#body-id').load('#body-id');--}}
{{--                            } else {--}}
{{--                                swal("Error!", results.message, "error");--}}
{{--                                // location.reload();--}}
{{--                            }--}}
{{--                        }--}}
{{--                    });--}}
{{--                }--}}
{{--                // alert(quantity);--}}
{{--                // return false;--}}
{{--                // Send AJAX request to update the cart--}}
{{--                $.ajax({--}}
{{--                    url: '{{url('updateCart')}}',--}}
{{--                    method: 'POST',--}}
{{--                    data: {--}}
{{--                        cartId: cartId,--}}
{{--                        quantity: quantity,--}}
{{--                        // Add other cart data fields if needed--}}
{{--                    },--}}
{{--                    success: function (response) {--}}
{{--                        // console.log('response');--}}
{{--                        // return false;--}}
{{--                        //location.reload();--}}
{{--                        // $('#body-id').load('#body-id');--}}
{{--                        // $('#cart-div').load('#cart-div');--}}

{{--                        const updatedSubtotal = response.updatedSubtotal;--}}
{{--                        $(this).closest('tr').find('.total-col').text('$' + updatedSubtotal);--}}
{{--                        location.reload();--}}
{{--                    },--}}
{{--                    error: function (xhr, status, error) {--}}
{{--                        // Handle error if needed--}}
{{--                    }--}}
{{--                });--}}
{{--            });--}}
{{--        });--}}
{{--    </script>--}}

    <script>
        $(document).ready(function() {
            const applyCouponBtn = $('#applyCouponBtn');
            const couponCodeInput = $('#couponCode');

            applyCouponBtn.click(function(event) {
                event.preventDefault();
                const couponCode = couponCodeInput.val();

                // Make an AJAX request to apply the coupon code
                $.ajax({
                    url: '{{ route('cart.apply_coupon') }}',
                    type: 'POST',
                    data: { coupon_code: couponCode },
                    dataType: 'json',
                    success: function(response) {
                        // Update the cart total with the discounted total
                        const summaryTotal = $('.summary-total td:last-child');
                        summaryTotal.text('$ ' + response.discounted_total.toFixed(2));
                        $('.final_amount').html('$ ' + response.discounted_total.toFixed(2));
                    },
                    error: function(xhr) {
                        console.log('Error:', xhr.responseText);
                    }
                });
            });
        });

        // jQuery code to remove a class on mobile screens
        $(document).ready(function () {
            function checkScreenWidth() {
                // Get the current screen width
                var screenWidth = $(window).width();

                // Define the breakpoint where you want to remove the class (e.g., 767px for mobile)
                var breakpoint = 767;

                // Check if the screen width is below the breakpoint
                if (screenWidth <= breakpoint) {
                    // Remove the class 'table-mobile' from the table
                    $('.table-mobile').removeClass('table-mobile');
                    $('.table-mobile').removeClass('product-col');
                    // $('.table-mobile').removeClass('quantity-col');
                    $('.table-mobile').removeClass('total-col');
                }
            }

            // Check the screen width on page load and on window resize
            checkScreenWidth();
            $(window).resize(checkScreenWidth);
        });

    </script>


@stop
{{--    <main class="main">--}}

{{--        <div class="heading heading-center mb-3">--}}
{{--            <h2 class="title mb-1">SHOPPING CART </h2>--}}
{{--            <hr class="fav_hr">--}}

{{--        </div>--}}
{{--        <nav aria-label="breadcrumb" class="breadcrumb-nav">--}}
{{--            <div class="container">--}}

{{--                        <ol class="breadcrumb">--}}
{{--                    <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>--}}
{{--                    <li class="breadcrumb-item active" aria-current="page">Shopping Cart</li>--}}
{{--                </ol>--}}
{{--                <style>--}}
{{--                    .breadcrumb-nav .container, .breadcrumb-nav .container-fluid {--}}
{{--                        padding-top: 1.4rem;--}}
{{--                        padding-bottom: 0.4rem;--}}
{{--                    }--}}
{{--                    a.backBtn {--}}
{{--                        border: 1px solid !important;--}}
{{--                        padding: 5px 4em !important;--}}
{{--                    }--}}
{{--                </style>--}}


{{--                </div>--}}

{{--            </div><!-- End .container -->--}}
{{--        </nav><!-- End .breadcrumb-nav -->--}}

{{--        <div class="page-content">--}}

{{--            <div class="cart" id="cart-div">--}}
{{--                <div class="container">--}}


{{--                    <div class="row">--}}

{{--                        <div class="col-lg-7">--}}

{{--                            <div class="table-responsive tablezoom">--}}

{{--                                <table class="table  table-cart table-mobile">--}}
{{--                                    <thead>--}}
{{--                                    <tr>--}}
{{--                                        <th>Image</th>--}}
{{--                                        <th>Product</th>--}}
{{--                                        <th>Quantity</th>--}}
{{--                                        <th>Total</th>--}}
{{--                                        <th>Remove</th>--}}
{{--                                    </tr>--}}
{{--                                    </thead>--}}

{{--                                    <tbody>--}}
{{--                                    @forelse($getAllCart as $getAllCarts)--}}
{{--                                        <tr>--}}
{{--                                            <td class="product-col">--}}
{{--                                                <a href="{{url('products/'.$getAllCarts->getProducts->slug)}}">--}}
{{--                                                    <img src="{{asset($getAllCarts->product_image)}}"--}}
{{--                                                         alt="{{$getAllCarts->getProducts->title ?? ''}}"--}}
{{--                                                    style="width:50px;">--}}
{{--                                                </a>--}}
{{--                                            </td>--}}
{{--                                            <td>--}}
{{--                                                <p class="product_cart_details" style="color:black;">--}}
{{--                                                    <a href="{{url('products/'.$getAllCarts->getProducts->slug)}}" style="color:black;">--}}
{{--                                                        {{$getAllCarts->getProducts->title ?? ''}}</a>--}}
{{--                                                    <br>--}}
{{--                                                    <b>Size :</b> {{$getAllCarts->size}}--}}
{{--                                                    <br>--}}
{{--                                                    <b>Brands : </b> {{ $getAllCarts->getBrands->category_name ?? 'NA' }}--}}
{{--                                                    <br>--}}
{{--                                                    <b>Category : </b> {{ $getAllCarts->getSection->category_name ?? 'NA' }}--}}
{{--                                                </p>--}}
{{--                                            </td>--}}
{{--                                            --}}{{--                                        <td class="price-col">${{$getAllCarts->per_piece_price}}</td>--}}
{{--                                            <td class="quantity-col">--}}
{{--                                                    <?php--}}
{{--                                                    $getAttrQty = \App\Models\Product::find($getAllCarts->product_id);--}}
{{--                                                    ?>--}}
{{--                                                <div class="cart-product-quantity">--}}
{{--                                                    <input type="number" class="form-control qty2"--}}
{{--                                                           data-cartid="{{$getAllCarts->id}}"--}}
{{--                                                           value="{{$getAllCarts->cartqty}}" min="0"--}}
{{--                                                           max="{{$getAttrQty->qty}}"--}}
{{--                                                           step="1" required>--}}
{{--                                                </div>--}}
{{--                                            </td>--}}
{{--                                            <td class="total-col">${{$getAllCarts->subtotal}}</td>--}}
{{--                                            <td class="remove-col">--}}
{{--                                                <a class="removebtn text-black" onclick="deleteConfirmation2({{$getAllCarts->id}})" data-cartid="{{$getAllCarts->id}}">--}}
{{--                                                    <i class="fa fa-trash"></i>--}}
{{--                                                </a>--}}
{{--                                            </td>--}}
{{--                                        </tr>--}}
{{--                                    @empty--}}
{{--                                    @endforelse--}}
{{--										<tr>--}}
{{--											<td colspan="2" style="padding:0px;border-bottom: none;">--}}
{{--												<a href="{{ url('delAllCartsProducts') }}" style="float:left;width:20%;padding:0px;" class="btn btn-order btn-block pb-2 pt-2 btn-outline-primary-2">--}}
{{--												Clear Cart--}}
{{--												</a>--}}
{{--											</td>--}}
{{--											<td colspan="3" style="padding:0px;border-bottom: none;">--}}
{{--											</td>--}}
{{--										</tr>--}}
{{--                                    </tbody>--}}
{{--                                </table>--}}

{{--                            </div>--}}


{{--                            <h4>Select Your Shipping Address.   </h4>--}}
{{--                            <div id="address-form">--}}
{{--                                <?php--}}
{{--                                if(Auth::check()) {--}}
{{--                                    $addresses = \App\Models\UserAddress::where('user_id', auth()->user()->id)->get();--}}
{{--                                    ?>--}}
{{--                                @forelse($addresses as $address)--}}

{{--                                    <div class="filter-item">--}}
{{--                                        <div class="custom-control custom-checkbox">--}}
{{--                                            <input type="checkbox" class="custom-control-input address-checkbox"--}}
{{--                                                   id="address-{{$address->id}}" name="selected_address" value="{{$address->id}}">--}}
{{--                                            <label class="custom-control-label"--}}
{{--                                                   for="address-{{$address->id}}">--}}
{{--                                                {{ $address->first_name }} {{ $address->last_name }}, {{$address->phone}}--}}
{{--                                                <br>--}}
{{--                                                {{$address->address_1}}, {{$address->address_2}}, {{$address->city}},--}}
{{--                                                {{$address->state}}, {{$address->pincode}}--}}
{{--                                            </label>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                    <div class="editbtn">--}}
{{--                                        <a href="{{url('edit-address/'.$address->id)}}"--}}
{{--                                           data-toggle="modal" data-target="#updateAddressModal{{$address->id}}"--}}
{{--                                           class="text-white btn-primary actionbtn">--}}
{{--                                            Edit</a>--}}
{{--                                        <a href="{{url('remove-address/'.$address->id)}}"--}}
{{--                                           class="actionbtn text-danger btn-warning">--}}
{{--                                            Remove</a>--}}
{{--                                    </div>--}}

{{--                                    <br>--}}

{{--                                    <div class="modal fade" id="updateAddressModal{{$address->id}}"--}}
{{--                                         tabindex="-1" role="dialog"--}}
{{--                                         aria-labelledby="exampleModalLabel" aria-hidden="true">--}}
{{--                                        <div class="modal-dialog" role="document">--}}
{{--                                            <div class="modal-content">--}}
{{--                                                <div class="modal-header">--}}
{{--                                                    <h2 class="checkout-title">Shipping Details</h2>--}}
{{--                                                    <h5 class="modal-title" id="exampleModalLabel">Update New Address</h5>--}}
{{--                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">--}}
{{--                                                        <span aria-hidden="true">&times;</span>--}}
{{--                                                    </button>--}}
{{--                                                </div>--}}
{{--                                                <div class="modal-body">--}}
{{--                                                    <div class="row">--}}
{{--                                                        <div class="col-md-12">--}}
{{--                                                            <form action="{{route('checkout.updateAddress')}}" method="post" id="newAddressForm2">--}}

{{--                                                                @csrf--}}
{{--                                                                <input type="hidden" name="address_id"--}}
{{--                                                                       value="{{$address->id}}">--}}
{{--                                                                <div class="row">--}}
{{--                                                                    <div class="col-sm-6">--}}
{{--                                                                        <label>First Name *</label>--}}
{{--                                                                        <input type="text" class="form-control"--}}
{{--                                                                               value="{{$address->first_name}}" name="first_name" required>--}}
{{--                                                                    </div>--}}

{{--                                                                    <div class="col-sm-6">--}}
{{--                                                                        <label>Last Name *</label>--}}
{{--                                                                        <input type="text" class="form-control"--}}
{{--                                                                               value="{{$address->last_name}}"--}}
{{--                                                                               name="last_name" required>--}}
{{--                                                                    </div>--}}

{{--                                                                </div>--}}

{{--                                                                <label>Country *</label>--}}
{{--                                                                <input type="text" class="form-control" name="country"--}}
{{--                                                                       value="USA"--}}
{{--                                                                       required>--}}
{{--                                                                <label>Street address *</label>--}}
{{--                                                                <input name="address_1" type="text" class="form-control"--}}
{{--                                                                       value="{{$address->address_1}}"--}}
{{--                                                                       placeholder="House number and Street name" required>--}}

{{--                                                                <input name="address_2" type="text" class="form-control"--}}
{{--                                                                       value="{{$address->address_2}}"--}}
{{--                                                                       placeholder="Apartments, suite, unit, etc ...">--}}

{{--                                                                <div class="row">--}}
{{--                                                                    <div class="col-sm-6">--}}
{{--                                                                        <label>Town / City *</label>--}}
{{--                                                                        <input name="city" type="text"--}}
{{--                                                                               value="{{$address->city}}"--}}
{{--                                                                               class="form-control" required>--}}
{{--                                                                    </div>--}}

{{--                                                                    <div class="col-sm-6">--}}
{{--                                                                        <label>State / County *</label>--}}
{{--                                                                        <input name="state" type="text"--}}
{{--                                                                               value="{{$address->state}}"--}}
{{--                                                                               class="form-control" required>--}}
{{--                                                                    </div>--}}
{{--                                                                </div>--}}

{{--                                                                <div class="row">--}}
{{--                                                                    <div class="col-sm-6">--}}
{{--                                                                        <label>Postcode / ZIP *</label>--}}
{{--                                                                        <input name="pincode" type="text"--}}
{{--                                                                               value="{{$address->pincode}}"--}}
{{--                                                                               class="form-control" required>--}}
{{--                                                                    </div>--}}

{{--                                                                    <div class="col-sm-6">--}}
{{--                                                                        <label>Phone *</label>--}}
{{--                                                                        <input name="phone" type="tel"--}}
{{--                                                                               value="{{$address->phone}}"--}}
{{--                                                                               class="form-control" required>--}}
{{--                                                                    </div>--}}

{{--                                                                </div>--}}

{{--                                                                <label>Email address *</label>--}}
{{--                                                                <input name="email" type="email" class="form-control"--}}
{{--                                                                       value="{{$address->email}}"--}}
{{--                                                                       required>--}}


{{--                                                                <div class="modal-footer">--}}
{{--                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>--}}
{{--                                                                    <button type="submit" class="btn btn-primary" id="saveAddressBtn">Save Address</button>--}}
{{--                                                                </div>--}}
{{--                                                            </form>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                </div>--}}
{{--                                            </div>--}}

{{--                                        </div>--}}
{{--                                    </div>--}}

{{--                                @empty--}}
{{--                                @endforelse--}}

{{--                                <label>--}}
{{--                                    <input type="checkbox" id="same_billing"--}}
{{--                                           name="same_billing_details" value="1"--}}
{{--                                    />--}}
{{--                                    Same as billing address--}}
{{--                                </label>--}}

{{--                                <br>--}}

{{--                                <a href="" class=" btn btn-block pb-2 pt-2--}}
{{--                                   btn-outline-primary-2 btn-success"--}}
{{--                                   data-toggle="modal" data-target="#addAddressModal"--}}

{{--                                > Add New Address</a>--}}

{{--                                <div class="modal fade" id="addAddressModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">--}}
{{--                                    <div class="modal-dialog" role="document">--}}
{{--                                        <div class="modal-content">--}}
{{--                                            <div class="modal-header">--}}
{{--                                                <h5 class="modal-title" id="exampleModalLabel">--}}
{{--                                                    Shipping Details--}}
{{--                                                </h5>--}}
{{--                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">--}}
{{--                                                    <span aria-hidden="true">&times;</span>--}}
{{--                                                </button>--}}
{{--                                            </div>--}}
{{--                                            <div class="modal-body">--}}
{{--                                                <div class="row">--}}
{{--                                                    <div class="col-md-12">--}}
{{--                                                        <form action="{{route('checkout.saveAddress')}}" method="post" id="newAddressForm2">--}}
{{--                                                            @csrf--}}
{{--                                                            <div class="row">--}}
{{--                                                                <div class="col-sm-6">--}}
{{--                                                                    <label>First Name *</label>--}}
{{--                                                                    <input type="text" class="form-control" name="first_name" required>--}}
{{--                                                                </div>--}}

{{--                                                                <div class="col-sm-6">--}}
{{--                                                                    <label>Last Name *</label>--}}
{{--                                                                    <input type="text" class="form-control" name="last_name" required>--}}
{{--                                                                </div>--}}

{{--                                                            </div>--}}

{{--                                                            <!--label>Company Name (Optional)</label>--}}
{{--                                                            <input type="text" class="form-control"-->--}}
{{--                                                            <label>Country *</label>--}}
{{--                                                            <input type="text" class="form-control" name="country" value="USA" required>--}}
{{--                                                            <label>Street address *</label>--}}
{{--                                                            <input name="address_1" type="text" class="form-control" placeholder="House number and Street name" required>--}}
{{--                                                            <input name="address_2" type="text" class="form-control" placeholder="Apartments, suite, unit, etc ...">--}}
{{--                                                            <div class="row">--}}
{{--                                                                <div class="col-sm-6">--}}
{{--                                                                    <label>Town / City *</label>--}}
{{--                                                                    <input name="city" type="text" class="form-control" required>--}}
{{--                                                                </div>--}}

{{--                                                                <div class="col-sm-6">--}}
{{--                                                                    <label>State / County *</label>--}}
{{--                                                                    <input name="state" type="text" class="form-control" required>--}}

{{--                                                                    <select name="state" class="form-control" required>--}}
{{--                                                                        <option value="AL">Alabama</option>--}}
{{--                                                                        <option value="AK">Alaska</option>--}}
{{--                                                                        <option value="AZ">Arizona</option>--}}
{{--                                                                        <option value="AR">Arkansas</option>--}}
{{--                                                                        <option value="CA">California</option>--}}
{{--                                                                        <option value="CO">Colorado</option>--}}
{{--                                                                        <option value="CT">Connecticut</option>--}}
{{--                                                                        <option value="DE">Delaware</option>--}}
{{--                                                                        <option value="FL">Florida</option>--}}
{{--                                                                        <option value="GA">Georgia</option>--}}
{{--                                                                        <option value="HI">Hawaii</option>--}}
{{--                                                                        <option value="ID">Idaho</option>--}}
{{--                                                                        <option value="IL">Illinois</option>--}}
{{--                                                                        <option value="IN">Indiana</option>--}}
{{--                                                                        <option value="IA">Iowa</option>--}}
{{--                                                                        <option value="KS">Kansas</option>--}}
{{--                                                                        <option value="KY">Kentucky</option>--}}
{{--                                                                        <option value="LA">Louisiana</option>--}}
{{--                                                                        <option value="ME">Maine</option>--}}
{{--                                                                        <option value="MD">Maryland</option>--}}
{{--                                                                        <option value="MA">Massachusetts</option>--}}
{{--                                                                        <option value="MI">Michigan</option>--}}
{{--                                                                        <option value="MN">Minnesota</option>--}}
{{--                                                                        <option value="MS">Mississippi</option>--}}
{{--                                                                        <option value="MO">Missouri</option>--}}
{{--                                                                        <option value="MT">Montana</option>--}}
{{--                                                                        <option value="NE">Nebraska</option>--}}
{{--                                                                        <option value="NV">Nevada</option>--}}
{{--                                                                        <option value="NH">New Hampshire</option>--}}
{{--                                                                        <option value="NJ">New Jersey</option>--}}
{{--                                                                        <option value="NM">New Mexico</option>--}}
{{--                                                                        <option value="NY">New York</option>--}}
{{--                                                                        <option value="NC">North Carolina</option>--}}
{{--                                                                        <option value="ND">North Dakota</option>--}}
{{--                                                                        <option value="OH">Ohio</option>--}}
{{--                                                                        <option value="OK">Oklahoma</option>--}}
{{--                                                                        <option value="OR">Oregon</option>--}}
{{--                                                                        <option value="PA">Pennsylvania</option>--}}
{{--                                                                        <option value="RI">Rhode Island</option>--}}
{{--                                                                        <option value="SC">South Carolina</option>--}}
{{--                                                                        <option value="SD">South Dakota</option>--}}
{{--                                                                        <option value="TN">Tennessee</option>--}}
{{--                                                                        <option value="TX">Texas</option>--}}
{{--                                                                        <option value="UT">Utah</option>--}}
{{--                                                                        <option value="VT">Vermont</option>--}}
{{--                                                                        <option value="VA">Virginia</option>--}}
{{--                                                                        <option value="WA">Washington</option>--}}
{{--                                                                        <option value="WV">West Virginia</option>--}}
{{--                                                                        <option value="WI">Wisconsin</option>--}}
{{--                                                                        <option value="WY">Wyoming</option>--}}
{{--                                                                    </select>--}}
{{--                                                                </div>--}}
{{--                                                            </div>--}}

{{--                                                            <div class="row">--}}
{{--                                                                <div class="col-sm-6">--}}
{{--                                                                    <label>Postcode / ZIP *</label>--}}
{{--                                                                    <input name="pincode" type="text" class="form-control" required>--}}
{{--                                                                </div>--}}

{{--                                                                <div class="col-sm-6">--}}
{{--                                                                    <label>Phone *</label>--}}
{{--                                                                    <input name="phone" type="tel" class="form-control" required>--}}
{{--                                                                </div>--}}

{{--                                                            </div>--}}

{{--                                                            <label>Email address *</label>--}}
{{--                                                            <input name="email" type="email" class="form-control" required>--}}
{{--                                                            <div class="custom-control custom-checkbox">--}}
{{--                                                                <input type="checkbox" class="custom-control-input" id="saveAddress" name="save_address">--}}
{{--                                                                <label class="custom-control-label" for="saveAddress">Save this address for future use</label>--}}
{{--                                                            </div>--}}

{{--                                                            <div class="modal-footer">--}}
{{--                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>--}}
{{--                                                                <button type="submit" class="btn btn-primary" id="saveAddressBtn">Save Address</button>--}}
{{--                                                            </div>--}}
{{--                                                        </form>--}}
{{--                                                    </div>--}}
{{--                                                </div>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}

{{--                                    </div>--}}
{{--                                </div>--}}




{{--                                <?php--}}
{{--                                }else{--}}
{{--                                    ?>--}}
{{--                                <div class="row">--}}
{{--                                    @if ($errors->any())--}}
{{--                                        <script>var error='';</script>--}}
{{--                                                @foreach ($errors->all() as $error)--}}
{{--												<script>error+='{{ $error }} </br>';</script>--}}

{{--                                                @endforeach--}}

{{--										   <script>swal(error);</script>--}}
{{--                                    @endif--}}

{{--                                    <div class="col-md-12">--}}
{{--                                        <form action="{{url('guest-checkout')}}" id="newAddressForm2">--}}


{{--                                            @csrf--}}
{{--                                            <div class="row">--}}
{{--                                                <div class="col-sm-6">--}}
{{--                                                    <label>First Name *</label>--}}
{{--                                                    <input type="text" class="form-control" name="first_name" required>--}}
{{--                                                </div>--}}

{{--                                                <div class="col-sm-6">--}}
{{--                                                    <label>Last Name *</label>--}}
{{--                                                    <input type="text" class="form-control" name="last_name" required>--}}
{{--                                                </div>--}}

{{--                                            </div>--}}

{{--                                            <label>Country *</label>--}}
{{--                                            <input type="text" class="form-control" name="country" value="USA" required>--}}
{{--                                            <label>Street address *</label>--}}
{{--                                            <input name="address_1" type="text" class="form-control" placeholder="House number and Street name" required>--}}
{{--                                            <input name="address_2" type="text" class="form-control" placeholder="Apartments, suite, unit, etc ...">--}}
{{--                                            <div class="row">--}}
{{--                                                <div class="col-sm-6">--}}
{{--                                                    <label>Town / City *</label>--}}
{{--                                                    <input name="city" type="text" class="form-control" required>--}}
{{--                                                </div>--}}

{{--                                                <div class="col-sm-6">--}}
{{--                                                    <label>State / County *</label>--}}
{{--                                                    <select name="state" class="form-control" required>--}}
{{--                                                        <option value="AL">Alabama</option>--}}
{{--                                                        <option value="AK">Alaska</option>--}}
{{--                                                        <option value="AZ">Arizona</option>--}}
{{--                                                        <option value="AR">Arkansas</option>--}}
{{--                                                        <option value="CA">California</option>--}}
{{--                                                        <option value="CO">Colorado</option>--}}
{{--                                                        <option value="CT">Connecticut</option>--}}
{{--                                                        <option value="DE">Delaware</option>--}}
{{--                                                        <option value="FL">Florida</option>--}}
{{--                                                        <option value="GA">Georgia</option>--}}
{{--                                                        <option value="HI">Hawaii</option>--}}
{{--                                                        <option value="ID">Idaho</option>--}}
{{--                                                        <option value="IL">Illinois</option>--}}
{{--                                                        <option value="IN">Indiana</option>--}}
{{--                                                        <option value="IA">Iowa</option>--}}
{{--                                                        <option value="KS">Kansas</option>--}}
{{--                                                        <option value="KY">Kentucky</option>--}}
{{--                                                        <option value="LA">Louisiana</option>--}}
{{--                                                        <option value="ME">Maine</option>--}}
{{--                                                        <option value="MD">Maryland</option>--}}
{{--                                                        <option value="MA">Massachusetts</option>--}}
{{--                                                        <option value="MI">Michigan</option>--}}
{{--                                                        <option value="MN">Minnesota</option>--}}
{{--                                                        <option value="MS">Mississippi</option>--}}
{{--                                                        <option value="MO">Missouri</option>--}}
{{--                                                        <option value="MT">Montana</option>--}}
{{--                                                        <option value="NE">Nebraska</option>--}}
{{--                                                        <option value="NV">Nevada</option>--}}
{{--                                                        <option value="NH">New Hampshire</option>--}}
{{--                                                        <option value="NJ">New Jersey</option>--}}
{{--                                                        <option value="NM">New Mexico</option>--}}
{{--                                                        <option value="NY">New York</option>--}}
{{--                                                        <option value="NC">North Carolina</option>--}}
{{--                                                        <option value="ND">North Dakota</option>--}}
{{--                                                        <option value="OH">Ohio</option>--}}
{{--                                                        <option value="OK">Oklahoma</option>--}}
{{--                                                        <option value="OR">Oregon</option>--}}
{{--                                                        <option value="PA">Pennsylvania</option>--}}
{{--                                                        <option value="RI">Rhode Island</option>--}}
{{--                                                        <option value="SC">South Carolina</option>--}}
{{--                                                        <option value="SD">South Dakota</option>--}}
{{--                                                        <option value="TN">Tennessee</option>--}}
{{--                                                        <option value="TX">Texas</option>--}}
{{--                                                        <option value="UT">Utah</option>--}}
{{--                                                        <option value="VT">Vermont</option>--}}
{{--                                                        <option value="VA">Virginia</option>--}}
{{--                                                        <option value="WA">Washington</option>--}}
{{--                                                        <option value="WV">West Virginia</option>--}}
{{--                                                        <option value="WI">Wisconsin</option>--}}
{{--                                                        <option value="WY">Wyoming</option>--}}
{{--                                                    </select>--}}

{{--                                                </div>--}}

{{--                                            </div>--}}

{{--                                            <div class="row">--}}
{{--                                                <div class="col-sm-6">--}}
{{--                                                    <label>Postcode / ZIP *</label>--}}
{{--                                                    <input name="pincode" type="text" class="form-control" required>--}}
{{--                                                </div>--}}

{{--                                                <div class="col-sm-6">--}}
{{--                                                    <label>Phone *</label>--}}
{{--                                                    <input name="phone" type="tel" class="form-control" required>--}}
{{--                                                </div>--}}

{{--                                            </div>--}}

{{--                                            <label>Email address *</label>--}}
{{--                                            <input name="email" type="email" class="form-control" required>--}}

{{--<input value="submit" type="submit" class="form-control" id="submithit" style="display:none;">--}}
{{--                                        </form>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                                <?php--}}

{{--                                }--}}
{{--                                ?>--}}
{{--                            </div>--}}

{{--                            <?php--}}
{{--                            $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '/admin/dashboard';--}}
{{--                            ?>--}}
{{--                            <a href="{{ url($referer) }}" class="btn btn-lg btn-raised btn-danger waves-effect" >Back</a>--}}




{{--                        </div>--}}

{{--                        <div class="col-lg-5">--}}

{{--                            <div class="summary summary-cart">--}}
{{--                                <h3 class="summary-title">Cart Total</h3><!-- End .summary-title -->--}}



{{--                                <table class="table table-summary">--}}
{{--                                    <tbody>--}}
{{--                                    <tr class="summary-subtotal">--}}
{{--                                        <td>Subtotal:</td>--}}
{{--                                        <td>--}}

{{--                                            @if(Session::has('discounted_total'))--}}
{{--                                                <p class="final_amount">--}}
{{--                                                    <strike>--}}
{{--                                                        $   {{$get_count->cartTotal ?? '0'}}--}}
{{--                                                    </strike>--}}
{{--                                                </p>--}}

{{--                                                $  {{Session::get('discounted_total') ?? '0'}}--}}

{{--                                            @else--}}
{{--                                                $ {{$get_count->cartTotal ?? '0'}}--}}
{{--                                            @endif--}}
{{--                                        </td>--}}
{{--                                    </tr><!-- End .summary-subtotal -->--}}

{{--                                    @if(Session::has('discounted_total'))--}}
{{--                                        <tr class="summary-subtotal">--}}
{{--                                            <td>Coupon Applied:</td>--}}
{{--                                            <td>--}}
{{--                                                {{Session::get('applied_coupon')}}--}}
{{--                                                <br>--}}
{{--                                                <span style="font-size:12px; color:red;">--}}
{{--                                                    <a href="{{url('remove-coupon')}}">Remove Coupon</a>--}}
{{--                                                </span>--}}
{{--                                            </td>--}}
{{--                                        </tr><!-- End .summary-subtotal -->--}}
{{--                                    @endif--}}

{{--                                    <tr class="summary-total">--}}
{{--                                        <td>Total:</td>--}}
{{--                                        <td>--}}

{{--                                            @if(Session::has('discounted_total'))--}}
{{--                                                $  {{number_format(Session::get('discounted_total'),2) ?? '0'}}--}}

{{--                                            @else--}}
{{--                                                $  {{number_format($get_count->cartTotal,2) ?? '0'}}--}}
{{--                                            @endif--}}
{{--                                        </td>--}}
{{--                                    </tr><!-- End .summary-total -->--}}
{{--                                    </tbody>--}}
{{--                                </table><!-- End .table table-summary -->--}}

{{--                                <a type="submit" href="{{ url('checkout') }}" data-addressid="{{ $selectedAddressId ?? '' }}"--}}
{{--                                   id="checkoutBtn"--}}
{{--                                   disabled--}}
{{--                                   class="btn btn-order btn-block pb-2 pt-2--}}
{{--                                   btn-outline-primary-2">--}}
{{--                                    PROCEED TO CHECKOUT--}}
{{--                                </a>--}}


{{--                            </div><!-- End .summary -->--}}

{{--						</div>--}}

{{--                    </div>--}}

{{--                </div><!-- End .container -->--}}
{{--            </div><!-- End .cart -->--}}
{{--        </div><!-- End .page-content -->--}}
{{--    </main>--}}

