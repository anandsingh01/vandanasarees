@extends('layouts.web')
<?php
session_start();
?>
@section('css')
<style>
    .sticky_header{
        position:unset;
    }
    .watch_header + main {
        margin-top: 0px;
    }

</style>

<style>
    .modal-full-width {
        width: 100%;
        max-width: 60%;
    }

    .modal-full-width .modal-content {
        width: 100%;
        /*max-width: 60%;*/
    }

    .billing_form .form_wrap {
        padding: 15px;
        border: 2px solid #e6e6e6;
    }
    .billing_form .checkbox_item {
        padding-left: 0;
    }
    #otpContainer {
        text-align: right;
        display: inline-block;
        width: 60%;
    }

    input#otpInput {
        width: 60%;
        padding: 15px;
    }
    section.body_yield_div {
        background: #fbfbfb;
    }
</style>
@stop
@section('body')
    <?php
    $get_cart = get_cart();
    $get_count = json_decode($get_cart);
    $prodTotal = $get_count->cartTotal;
    $getAllCart = getCartProducts();
    ?>

        <!-- breadcrumb_section - start
       ================================================== -->
{{--    <section class="breadcrumb_section text-white text-center text-uppercase d-flex align-items-end clearfix"--}}
{{--             data-background="{{asset('images/webp/74651700935498.webp')}}">--}}
{{--        <div class="overlay" data-bg-color="#1d1d1d"></div>--}}
{{--        <div class="container">--}}
{{--            <h1 class="page_title text-white">Checkout</h1>--}}
{{--            <ul class="breadcrumb_nav ul_li_center clearfix">--}}
{{--                <li><a href="#!">Home</a></li>--}}
{{--                <li>Shop</li>--}}
{{--                <li>Checkout</li>--}}
{{--            </ul>--}}
{{--        </div>--}}
{{--    </section>--}}
    <!-- breadcrumb_section - end
       ================================================== -->


    <!-- checkout_section - start
   ================================================== -->
    <section class="checkout_section sec_ptb_140 clearfix">
        <div class="container">
            <ul class="checkout_step ul_li clearfix">
                <li ><a href="{{url('/checkout/cart')}}"><span>01.</span> Shopping Cart</a></li>
                <li class="active"><a href="javascript:void(0)"><span>02.</span> Checkout</a></li>
                <li><a href="javascript:void(0)"><span>03.</span> Order Completed</a></li>
            </ul>
{{--            <div class="row">--}}
{{--                <div class="col-lg-6">--}}
{{--                    <div class="checkout_collapse_content">--}}
{{--                        <div class="wrap_heade">--}}
{{--                            <p class="mb-0">--}}
{{--                                Returning customer? <a class="collapsed" data-toggle="collapse" href="#loginform_collapse" aria-expanded="false" role="button">Click here to login</a>--}}
{{--                            </p>--}}
{{--                        </div>--}}
{{--                        <div id="loginform_collapse" class="collapse_form_wrap collapse">--}}
{{--                            <div class="card-body">--}}
{{--                                <form action="#">--}}
{{--                                    <div class="row">--}}
{{--                                        <div class="col-lg-6">--}}
{{--                                            <div class="form_item">--}}
{{--                                                <input type="email" name="email" placeholder="Email">--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                        <div class="col-lg-6">--}}
{{--                                            <div class="form_item">--}}
{{--                                                <input type="password" name="password" placeholder="Password">--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                    <div class="login_button">--}}
{{--                                        <div class="checkbox_item">--}}
{{--                                            <label for="remember_checkbox"><input id="remember_checkbox" type="checkbox"> Remember me</label>--}}
{{--                                        </div>--}}
{{--                                        <button type="submit" class="custom_btn bg_default_red">Login Now</button>--}}
{{--                                    </div>--}}
{{--                                </form>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <div class="col-lg-6">--}}
{{--                    <div class="checkout_collapse_content">--}}
{{--                        <div class="wrap_heade">--}}
{{--                            <p class="mb-0">--}}
{{--                                <i class="ti-info-alt"></i>--}}
{{--                                Have a coupon? <a class="collapsed" data-toggle="collapse" href="#coupon_collapse" aria-expanded="false">Click here to enter your code</a>--}}
{{--                            </p>--}}
{{--                        </div>--}}
{{--                        <div id="coupon_collapse" class="collapse_form_wrap collapse">--}}
{{--                            <div class="card-body">--}}
{{--                                <form action="#">--}}
{{--                                    <div class="form_item">--}}
{{--                                        <input type="text" name="coupon" placeholder="Coupon Code">--}}
{{--                                    </div>--}}
{{--                                    <button type="submit" class="custom_btn bg_default_red">Apply coupon</button>--}}
{{--                                </form>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
            <form action="{{url('checkout/submit')}}" method="post">
                <div class="row">
                    <div class="col-md-6">
                        <div class="billing_form mb_50">
                            <h3 class="form_title mb_30">Billing details</h3>

                            @csrf
                            <div class="form_wrap">
                                <div class="form_item">
                                    <span class="input_title">First Name<sup>*</sup></span>
                                    <input type="text" name="first_name" required>
                                </div>
                                <div class="form_item">
                                    <span class="input_title">Last Name<sup>*</sup></span>
                                    <input type="text" name="last_name" required>
                                </div>

                                <div class="form_item">
                                    <span class="input_title">Address<sup>*</sup></span>
                                    <input type="text" name="address_1" required placeholder="House number and street name">
                                </div>
                                <div class="form_item">
                                    <span class="input_title">Town/City<sup>*</sup></span>
                                    <input type="text" name="city" required>
                                </div>
                                <div class="form_item">
                                    <span class="input_title">State<sup>*</sup></span>
                                    <input type="text" name="state" required>
                                </div>
                                <div class="form_item">
                                    <span class="input_title">Postcode / Zip<sup>*</sup></span>
                                    <input type="text" name="pincode"
                                           required
                                           maxlength="6"
                                           pattern="\d{6}"
                                           oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1').replace(/^0[^.]/, '');"

                                           title="Please enter exactly 6 digits">

                                </div>
                                <div class="form_item">
                                    <span class="input_title">Phone<sup>*</sup></span>
                                    <input type="tel" name="phone"
                                           maxlength="10"
                                           pattern="\d{10}"
                                           oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1').replace(/^0[^.]/, '');"
                                           id="mobileInput"
                                    >
                                </div>
                                <div class="form_item">
                                    <span class="input_title">Email Address<sup>*</sup></span>
                                    <input type="email" name="email" required>
                                </div>
                                <div class="checkbox_item">
                                    <label for="account_create_checkbox">
                                        <input id="account_create_checkbox" value="yes" name="create_account" type="checkbox"> Create an account?</label>
                                </div>
                                <hr>
{{--                                <div class="checkbox_item mb_30">--}}
{{--                                    <label for="ship_address_checkbox">--}}
{{--                                        <input id="ship_address_checkbox" name="different_address"--}}
{{--                                               value="yes"--}}
{{--                                               type="checkbox"> Ship to a different address?--}}
{{--                                    </label>--}}
{{--                                </div>--}}

{{--                                <div id="popup_address" style="display: none;">--}}
{{--                                    <div class="billing_form mb_50">--}}

{{--                                        @csrf--}}
{{--                                        <div class="form_wrap">--}}
{{--                                            <div class="row">--}}
{{--                                                <div class="col-lg-6">--}}
{{--                                                    <div class="form_item">--}}
{{--                                                        <span class="input_title">First Name<sup>*</sup></span>--}}
{{--                                                        <input type="text" name="billing_first_name">--}}
{{--                                                    </div>--}}
{{--                                                </div>--}}
{{--                                                <div class="col-lg-6">--}}
{{--                                                    <div class="form_item">--}}
{{--                                                        <span class="input_title">Last Name<sup>*</sup></span>--}}
{{--                                                        <input type="text" name="billing_last_name">--}}
{{--                                                    </div>--}}
{{--                                                </div>--}}
{{--                                            </div>--}}
{{--                                            <div class="form_item">--}}
{{--                                                <span class="input_title">Country<sup>*</sup></span>--}}
{{--                                                <input type="text" name="billing_country">--}}
{{--                                            </div>--}}

{{--                                            <div class="form_item">--}}
{{--                                                <span class="input_title">Address<sup>*</sup></span>--}}
{{--                                                <input type="text" name="billing_address_1" placeholder="House number and street name">--}}
{{--                                            </div>--}}

{{--                                            <div class="form_item">--}}
{{--                                                <span class="input_title">Address<sup>*</sup></span>--}}
{{--                                                <input type="text" name="billing_address_2" placeholder="House number and street name">--}}
{{--                                            </div>--}}
{{--                                            <div class="form_item">--}}
{{--                                                <span class="input_title">Town/City<sup>*</sup></span>--}}
{{--                                                <input type="text" name="billing_city">--}}
{{--                                            </div>--}}
{{--                                            <div class="form_item">--}}
{{--                                                <span class="input_title">State<sup>*</sup></span>--}}
{{--                                                <input type="text" name="billing_state">--}}
{{--                                            </div>--}}
{{--                                            <div class="form_item">--}}
{{--                                                <span class="input_title">Postcode / Zip<sup>*</sup></span>--}}
{{--                                                <input type="text" name="pincode"--}}
{{--                                                       maxlength="6"--}}
{{--                                                       pattern="\d{6}"--}}
{{--                                                       oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1').replace(/^0[^.]/, '');"--}}

{{--                                                       title="Please enter exactly 6 digits">--}}

{{--                                            </div>--}}
{{--                                            <div class="form_item">--}}
{{--                                                <span class="input_title">Phone<sup>*</sup></span>--}}
{{--                                                <input type="tel" name="billing_phone"--}}
{{--                                                       maxlength="10"--}}
{{--                                                       pattern="\d{10}"--}}
{{--                                                       oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1').replace(/^0[^.]/, '');"--}}

{{--                                                >--}}
{{--                                            </div>--}}
{{--                                            <div class="form_item">--}}
{{--                                                <span class="input_title">Email Address<sup>*</sup></span>--}}
{{--                                                <input type="email" name="billing_email">--}}
{{--                                            </div>--}}
{{--                                        </div>--}}

{{--                                    </div>--}}
{{--                                </div>--}}

{{--                                <div class="form_item mb-0">--}}
{{--                                    <span class="input_title">Order notes<sup>*</sup></span>--}}
{{--                                    <textarea name="note" placeholder="Note about your order,"></textarea>--}}
{{--                                </div>--}}
                            </div>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="billing_form">
                            <h3 class="form_title mb_30">Your order</h3>

                            <div class="form_wrap">
                                <div class="checkout_table">
                                    <table class="table text-center mb_50">
                                        <thead class="text-uppercase text-uppercase">
                                        <tr>
                                            <th>Product Name</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Total</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @forelse($getAllCart as $getAllCarts)
                                            <tr>
                                                <td>
                                                    <div class="cart_product">
                                                        <div class="item_image">
                                                            <img src="{{asset($getAllCarts->getProducts->photo)}}" alt="image_not_found">
                                                        </div>
                                                        <div class="item_content">
                                                            <h4 class="item_title"> {{$getAllCarts->getProducts->title ?? ''}}</h4>
                                                            <span class="item_type">

                                                        <?php
                                                                    $getcategory = \App\Models\Category::where('id',$getAllCarts->getProducts->section_id)->first();
                                                                    ?>

                                                                {{$getcategory->category_name}}
                                                    </span>


                                                            @if(!empty($getAllCarts->getColor->attribute_value))
                                                                <?php
                                                                $getColor = \App\Models\AttributeValue::where('id',$getAllCarts->getColor->attribute_value)->first();
                                                                ?>

                                                            <p>Color : @if(!empty($getAllCarts->getColor->image))
                                                                    <img src="{{asset($getAllCarts->getColor->image)}}" style="
                                                                     width:10px;
                                                                     height:10px;
                                                                     border-radius: 50%;
                                                                     object-fit: cover;">
                                                                @else
                                                                    Default
                                                                @endif
                                                            </p>

                                                            @else
                                                                <p>Color :  <img src="https://dictionaryblog.cambridge.org/wp-content/uploads/2020/07/black-and-white-1.png?w=300"
                                                                                 style=" width:10px;
                                         height:10px;
                                         border-radius: 50%;
                                         object-fit: cover;"
                                                                    >
                                                                </p>
                                                                @endif

                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span class="price_text">Rs. {{$getAllCarts->per_piece_price}}</span>
                                                </td>
                                                <td>

                                                    <span class="quantity_text">{{$getAllCarts->cartqty}}</span>
                                                </td>
                                                <td><span class="total_price{{$getAllCarts->id}}" id="total_price{{$getAllCarts->id}}">Rs. {{$getAllCarts->subtotal}}</span></td>
                                            </tr>
                                            <input type="hidden" name="product_name[]" value="{{$getAllCarts->getProducts->title}}"/>
                                            <input type="hidden" name="product_id[]" value="{{$getAllCarts->getProducts->id}}"/>
                                            <input type="hidden" name="product_color[]" value="{{$getAllCarts->getColor->attribute_value ?? 'Default'}}"/>
                                            <input type="hidden" name="qty[]" value="{{$getAllCarts->cartqty}}"/>
                                            <input type="hidden" name="price[]" value="{{$getAllCarts->price}}"/>
                                            <input type="hidden" name="per_piece_price[]" value="{{$getAllCarts->per_piece_price}}"/>
                                            {{--                                    <input type="hidden" name="size[]" value="{{$getAllCarts->size}}"/>--}}
                                            {{--                                    <input type="hidden" name="height[]" value="{{$getAllCarts->height}}"/>--}}
                                            {{--                                    <input type="hidden" name="width[]" value="{{$getAllCarts->width}}"/>--}}
                                            {{--                                    <input type="hidden" name="length[]" value="{{$getAllCarts->length}}"/>--}}
                                        @empty
                                        @endforelse


                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <span class="subtotal_text">Subtotal</span>
                                            </td>
                                            <td><span class="total_price">Rs. {{$getsubtotal}}</span></td>
                                        </tr>
{{--                                        <tr>--}}
{{--                                            <td></td>--}}
{{--                                            <td></td>--}}
{{--                                            <td>--}}
{{--                                                <span class="subtotal_text">Shipping</span>--}}
{{--                                            </td>--}}
{{--                                            <td class="text-left">--}}
{{--                                                <div class="checkbox_item mb_15">--}}
{{--                                                    <label for="shipping_checkbox"><input id="shipping_checkbox" type="checkbox" checked> Free Shipping</label>--}}
{{--                                                </div>--}}
{{--                                                <div class="checkbox_item mb_15">--}}
{{--                                                    <label for="flatrate_checkbox"><input id="flatrate_checkbox" type="checkbox"> Flat rate: $15.00</label>--}}
{{--                                                </div>--}}
{{--                                                <div class="checkbox_item">--}}
{{--                                                    <label for="localpickup_checkbox"><input id="localpickup_checkbox" type="checkbox"> Local Pickup: $8.00</label>--}}
{{--                                                </div>--}}
{{--                                            </td>--}}
{{--                                        </tr>--}}
                                        <tr>
                                            <td class="text-left">
                                                <span class="subtotal_text">TOTAL</span>
                                            </td>
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <span class="total_price">Rs. {{$getsubtotal}}</span>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="billing_payment_mathod">
                                    <ul class="ul_li_block clearfix">

                                        <li>
                                            <div class="checkbox_item mb-0 pl-0">
                                                <label for="cash_delivery">
                                                    <input id="cash_delivery" required name="payment_mode" value="cod" type="radio" > Cash On Delivery</label>
                                                <!-- Button to trigger OTP -->
                                                <!-- Container for OTP-related elements -->
                                                <div id="otpContainer" style="display: none;">
                                                    <a id="getOtpBtn">Get OTP</a>


                                                </div>
                                                <!-- OTP input field and verification button -->
                                                <div id="otpInputContainer" style="display: none;">
                                                    <input type="text" id="otpInput" placeholder="Enter OTP">
                                                    <a id="verifyOtpBtn">Verify OTP</a>
                                                </div>
                                            </div>


                                        </li>
                                        <li>
                                            <div class="checkbox_item mb-0 pl-0">
                                                <label for="cash_delivery2">
                                                    <input id="cash_delivery2" required name="payment_mode" value="online" type="radio"> Pay Online </label>
                                            </div>
                                        </li>
                                    </ul>
                                    <button type="submit" class="custom_btn bg_default_red" id="placeOrderBtn">PLACE ORDER</button>
                                </div>
                            </div>

                            <input type="hidden" name="subtotal" value="{{$getsubtotal}}"/>
                            <input type="hidden" name="final_amount" value="{{$getsubtotal}}"/>
                            <input type="hidden" name="coupon_code" value=""/>

                        </div></div>
                </div>



            </form>
        </div>


    </section>
    <!-- checkout_section - end
       ================================================== -->

@stop
@section('js')
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.all.min.js"></script>
    @if(Session::has('error'))
        <script>
            swal("Address not found");
            // location.reload();
            // console.log(data.success)
        </script>
    @endif


    <script>
        $(document).ready(function() {
            // Get references to the elements
            var otpContainer = $('#otpContainer');
            var otpInputContainer = $('#otpInputContainer');
            var getOtpBtn = $('#getOtpBtn');
            var verifyOtpBtn = $('#verifyOtpBtn');
            var placeOrderBtn = $('#placeOrderBtn');

            $('#cash_delivery2').change(function() {
                placeOrderBtn.prop('disabled', false);
                otpContainer.hide();
                otpInputContainer.hide();
            });

            // Add event listener to the radio button
            $('#cash_delivery').change(function() {
                placeOrderBtn.prop('disabled', true);

                // Toggle visibility of OTP-related elements based on the selection
                if ($(this).prop('checked')) {
                    otpContainer.show();
                    otpInputContainer.show(); // Show OTP input on successful response
                    otpInputContainer.hide(); // Hide OTP input initially
                } else {
                    otpContainer.hide();
                    otpInputContainer.hide();
                }
            });

            // Add event listener to the "Get OTP" button
            getOtpBtn.click(function() {
                var phone = $('#mobileInput').val();

                console.log('Sending AJAX request for OTP...');

                $.ajax({
                    url: '{{ url("otp_for_cod/") }}',
                    method: 'get',
                    dataType: 'json', // Specify the expected data type
                    data:{
                        phone : phone
                    },
                    contentType: 'application/json', // Specify the content type
                    success: function(response) {
                        console.log('AJAX success:', response);

                        if (response.code == 200) {
                            $('#otpInputContainer').show();
                        } else {
                            alert('Failed to send OTP. Please try again.');
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error('AJAX Error:', textStatus, errorThrown);
                        alert('Error sending OTP. Please try again.');
                    }
                });
            });

            // Add event listener to the "Verify OTP" button
            verifyOtpBtn.click(function() {
                // Perform AJAX to verify OTP (replace with your actual URL and data)
                $.ajax({
                    url: '{{url("verify-codotp")}}',
                    method: 'POST',
                    data: {
                        otp: $('#otpInput').val() ,// Include the entered OTP
                        phone: $('#mobileInput').val() // Include the entered OTP
                    },
                    success: function(response) {
                        console.log(response);
                        if (response.code == 200) {
                            alert('OTP Verified!');
                            placeOrderBtn.prop('disabled', false); // Enable Place Order button
                        } else {
                            alert('OTP verification failed. Please try again.');
                        }
                    },
                    error: function() {
                        alert('Error verifying OTP. Please try again.');
                    }
                });
            });
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#ship_address_checkbox').on('change', function () {
                if ($(this).is(':checked')) {
                    $('#popup_address').show();
                } else {
                    $('#popup_address').hide();
                }
            });
        });
    </script>
    <script>
        $(document).ready(function () {

            $('#different_address').css('display', 'block');

            $('#same_billing').on('change', function () {
                if (this.checked) {
                    // alert('yes');
                    // If the checkbox is checked, hide 'different_address' and show 'same_address'
                    // $('#different_address').css('display', 'none');
                    //  $('#same_address').css('display', 'block');
                    $('#shipping_first_name').val($('#billing_first_name').val());
                    $('#shipping_last_name').val($('#billing_last_name').val());
                    $('#shipping_city').val($('#billing_city').val());
                    $('#shipping_state').val($('#billing_state').val());
                    $('#shipping_street').val($('#billing_street').val());
                    $('#shipping_street2').val($('#billing_street2').val());
                    $('#shipping_country').val($('#billing_country').val());
                    $('#shipping_zip').val($('#billing_zip').val());
                    $('#shipping_email').val($('#billing_email').val());
                    $('#shipping_phone').val($('#billing_phone').val());


                }
                if($("#same_billing").prop('checked') == false){
                    //alert('no');
                    // If the checkbox is unchecked, hide 'same_address' and show 'different_address'
                    //$('#same_address').css('display', 'none');
                    // $('#different_address').css('display', 'block');
                    // $('#shipping_first_name').val(""));
                    $('#shipping_first_name').val(null);
                    $('#shipping_last_name').val(null);
                    $('#shipping_city').val(null);
                    $('#shipping_state').val(null);
                    $('#shipping_street').val(null);
                    $('#shipping_street2').val(null);
                    $('#shipping_country').val(null);
                    $('#shipping_zip').val(null);
                    $('#shipping_email').val(null);
                    $('#shipping_phone').val(null);


                }
            });
        });

    </script>
    <script>
        $(document).ready(function () {

            //$("#freeshipval").hide();
            $("#finalpay").hide();
            const $addressRadioButtons = $('input[name="selected_address"]');
            const $manualForm = $('.manual-form');
            const $savedAddresses = $('.saved-addresses');

            const $shippingOptions = $('#shipping-options');
            const $selectedCourier = $('#courier-select');
            const $shippingPriceInput = $('#shipping-price'); // Update this line
            const $totalAmountInput = $('#total-amount'); // Add this line

            const $pincodeInput = $('input[name="pincode"]');
            const sum_length = $('.sLength').val();
            const sum_width = $('.sWidth').val();
            const sum_height = $('.sHeight').val();
            const $finalAmountInput = $('#final-amount'); // Define the input field for the final amount

            let ratesArray = [];

            let salesTax = 0;
            const debounceDelay = 100;
            let shippingTimer;



            $(document).ready(function () {
                clearTimeout(shippingTimer);

                const zipCode = $('#zipcode').val();
                // alert(zipCode);
                // return false;

                // Only fetch sales tax if ZIP code is 5 or more digits
                if (zipCode.length >= 5) {
                    shippingTimer = setTimeout(function () {
                        fetchSalesTax(zipCode);
                    }, debounceDelay);
                }
            });

            function fetchSalesTax(zipCode) {

                $.ajax({
                    method: 'GET',
                    url: 'https://api.api-ninjas.com/v1/salestax?zip_code=' + zipCode,
                    headers: { 'X-Api-Key': '4NZW/DZKECPyubyiLhZvcg==LEgqG60lhPyYuwSn' }, // Replace with your API key
                    contentType: 'application/json',
                    success: function (result) {

                        var ptot = "<?php echo $productTotal = $get_count->cartTotal; ?>";

                        const salesTaxRate = parseFloat(result[0].total_rate);
                        const productTotal = parseFloat(ptot) ;

                        const totalAmount = productTotal + (productTotal * salesTaxRate);

                        // Display calculated values with $ sign in div elements
                        $('.salesTaxDiv').text('$' + (productTotal * salesTaxRate).toFixed(2));
                        $('.finalTaxDiv').text('$' + totalAmount.toFixed(2));

                        // Set calculated values in input fields without $ sign
                        $('#sales-tax').val((productTotal * salesTaxRate).toFixed(2));
                        $finalAmountInput.val(totalAmount.toFixed(2));
                    },
                    error: function (jqXHR) {

                        console.error('Error fetching sales tax:', jqXHR.responseText);
                    }
                });
            }


            // Event listener for the courier select input
            $selectedCourier.on('change', function () {

                const shippingPrice = $(this).val();

                const salesTax = parseFloat($('#sales-tax').val());
                if(salesTax=='' || salesTax== null){
                    salesTax=0;
                }

                const productTotal = parseFloat($('input[name="product_total"]').val());

                const selectedRate = shippingPrice;


                const selectedCourier1 = $(this).val();
                if(selectedCourier1==10){
                    $("#finalpay").hide();
                }else{
                    $("#finalpay").show();
                }

                //  alert(selectedCourier1);
                // return false;


                if (!isNaN(productTotal)) {

                    if (selectedRate) {


                        $shippingPriceInput.val(selectedRate);

                        const newFinalAmount = parseFloat(salesTax) + parseFloat(productTotal) + parseFloat(selectedRate);
                        //alert(newFinalAmount );
                        $finalAmountInput.val(newFinalAmount.toFixed(2));
                        $('.finalTaxDiv').text('$' + newFinalAmount.toFixed(2));

                        const courierName = $selectedCourier.find(':selected').attr('data-name');

                        $(".issubmit").hide();
                        // alert(courierName);
                        // return false;

                        // if(selectedRate == 0){
                        //     const courierName = $selectedCourier.find(':selected').attr('data-name');
                        // }else{
                        //     const courierName = $selectedCourier.find(':selected').attr('data-name');
                        // }

                        $('#courier-name').val(courierName);
                        $('#selected_del').text('$' + selectedRate);
                    } else {

                        $shippingPriceInput.val('N/A');
                        $finalAmountInput.val(productTotal.toFixed(2));
                        $('.finalTaxDiv').text('$' + productTotal.toFixed(2));
                        $('#courier-name').val('N/A');
                    }
                } else {
                    //  alert('abc');
                    // return false;

                    $finalAmountInput.val('N/A');
                    $('#courier-name').val('');
                }
            });

            // Initial call to fetch and display shipping options
            fetchShippingOptions($pincodeInput.val());

            // Initial call to calculate sales tax
            fetchSalesTax($pincodeInput.val());
        });

        $(document).ready(function () {

            const $formFields = {
                first_name: $('input[name="first_name"]'),
                last_name: $('input[name="last_name"]'),
                country: $('input[name="country"]'),
                address_1: $('input[name="address_1"]'),
                address_2: $('input[name="address_2"]'),
                city: $('input[name="city"]'),
                state: $('input[name="state"]'),
                pincode: $('input[name="pincode"]'),
                phone: $('input[name="phone"]'),
                email: $('input[name="email"]')
            };

            function showSavedAddresses() {
                $savedAddresses.show();
                $manualForm.hide();
            }

            function showManualForm() {
                $savedAddresses.hide();
                $manualForm.show();
            }

            function populateAddressFields(address) {
                for (const field in $formFields) {
                    $formFields[field].val(address[field]);
                }
            }

            function clearFormFields() {
                for (const field in $formFields) {
                    $formFields[field].val('');
                }
            }

            $addressRadioButtons.on('change', function () {
                const selectedAddressId = $(this).val();
                if (selectedAddressId !== '') {
                    const selectedAddress = addresses.find(address => address.id === parseInt(selectedAddressId));
                    populateAddressFields(selectedAddress);
                    fetchShippingOptions(selectedAddress.pincode);
                    fetchSalesTax(selectedAddress.pincode);
                } else {
                    clearFormFields();
                    $shippingOptions.empty();
                    $selectedCourier.html('');
                }
            });

            $pincodeInput.on('keyup', function () {
                fetchShippingOptions($(this).val());
            });

            $('input[name="shipping_option"]').on('change', function () {
                $selectedCourier.html(`Selected Courier: ${$(this).val()}`);
            });

            (isAuthenticated && addresses.length > 0) ? showSavedAddresses() : showManualForm();
        });

    </script>
    <script>
        $(document).ready(function() {
            const applyCouponBtn = $('#applyCouponBtn');
            const couponCodeInput = $('#couponCode');

            applyCouponBtn.click(function(event) {
                event.preventDefault();
                const couponCode = couponCodeInput.val();

                // Make an AJAX request to apply the coupon code
                $.ajax({
                    url: '{{ route('cart.apply_coupon') }}',
                    type: 'POST',
                    data: { coupon_code: couponCode },
                    dataType: 'json',
                    success: function(response) {

                        // Update the cart total with the discounted total
                        const summaryTotal = $('.summary-total td:last-child');
                        summaryTotal.text('$ ' + response.discounted_total.toFixed(2));
                        $('.final_amount').html('$ ' + response.discounted_total.toFixed(2));
                        $('#body-id').load('#body-id');
                    },
                    error: function(xhr) {
                        console.log('Error:', xhr.responseText);
                    }
                });
            });
        });

    </script>
@stop

