<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Product_size;
use Illuminate\Http\Request;
use App\Models\Section;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\Facades\Image;
use Intervention\Image\ImageManager;

class SectionController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $data['page_heading'] = 'Section';
        $data['categories'] = Section::orderBy('id','DESC')->get();
        return view('admin.section.index',$data);
    }

    public function create(Request $request)
    {

//        print_r($request->all());die;

        if(isset($request->name_slug)){
            $slug = str_replace(' ','-',strtolower($request->name));
        }else{
            $slug = str_replace(' ','-',strtolower($request->name));
        }
        $data = [
            'slug' => $slug
        ];

        $category = Section::where('slug',$data['slug'])->count();
        $savecategory = new Section;
        if($category <= 0){
            $savecategory->slug = $data['slug'];

        }else{
            $savecategory->slug = $data['slug'].'-'.rand(11,99);
        }

        $savecategory->category_type = $request->category_type;
        $savecategory->category_name = $request->name;
        $savecategory->parent_id = 0;
        $savecategory->show_on_menu = $request->show_on_menu;
        $savecategory->show_on_homepage = $request->show_at_homepage;
        $savecategory->banner_text = $request->banner_text;


        $savecategory->meta_title = $request->meta_title;
        $savecategory->meta_description	 = $request->meta_description	;

        if ($request->hasFile('image')) {
            $newimage = $request->file('image');

            // Define the path where you want to store the uploaded image
            $path = 'images';
            $path2 = 'images/webp';
            $uniqueimagename = rand(1111,9999).time();
            $uniqueimage_original = $uniqueimagename.'.'.$newimage->getClientOriginalExtension();

            $other_format_path  = $newimage->move($path, $uniqueimage_original);
            $manager = new ImageManager(new Driver());
            $image = $manager->read($other_format_path);

            $encoded = $image->toWebp()->save($path2.'/'.$uniqueimagename.'.webp');
            $complete_path = $path2.'/'.$uniqueimagename.'.webp';

            $savecategory->image = $complete_path;

        }

        if ($request->hasFile('banner_image')) {
            $newimage = $request->file('banner_image');

            // Define the path where you want to store the uploaded image
            $path = 'images';
            $path2 = 'images/webp';
            $uniqueimagename = rand(1111,9999).time();
            $uniqueimage_original = $uniqueimagename.'.'.$newimage->getClientOriginalExtension();

            $other_format_path  = $newimage->move($path, $uniqueimage_original);
            $manager = new ImageManager(new Driver());
            $image = $manager->read($other_format_path);

            $encoded = $image->toWebp()->save($path2.'/'.$uniqueimagename.'.webp');
            $complete_path = $path2.'/'.$uniqueimagename.'.webp';

            $savecategory->banner_image = $complete_path;

        }



        $savecategory->status = '1';
        if($savecategory->save()){
            return redirect()->back()->with('success','Section Saved');
        }
    }

    public function edit($id)
    {
        $data['page_heading'] = 'Section';
        $data['category'] = Section::find($id);
        return view('admin.section.edit',$data);
    }
    public function update(Request $request)
    {

        if(isset($request->slug)){
            $slug = str_replace(' ','-',strtolower($request->slug));
        }else{
            $slug = str_replace(' ','-',strtolower($request->name));
        }
        $data = [
            'slug' => $slug
        ];

        $category = Section::where('id',$request->id)->where('slug',$data['slug'])->count();
        $savecategory = Section::find($request->id);

        $savecategory->category_name = $request->name;
        $savecategory->parent_id = 0;

        $savecategory->show_on_menu = $request->show_on_menu;
        $savecategory->show_on_homepage = $request->show_at_homepage;
        $savecategory->banner_text = $request->banner_text;
        $savecategory->meta_title = $request->meta_title;
        $savecategory->meta_description	 = $request->meta_description	;

        if ($request->hasFile('banner_image')) {
            $newimage = $request->file('banner_image');

            // Define the path where you want to store the uploaded image
            $path = 'images';
            $path2 = 'images/webp';
            $uniqueimagename = rand(1111,9999).time();
            $uniqueimage_original = $uniqueimagename.'.'.$newimage->getClientOriginalExtension();

            $other_format_path  = $newimage->move($path, $uniqueimage_original);
            $manager = new ImageManager(new Driver());
            $image = $manager->read($other_format_path);

            $encoded = $image->toWebp()->save($path2.'/'.$uniqueimagename.'.webp');
            $complete_path = $path2.'/'.$uniqueimagename.'.webp';

            $savecategory->banner_image = $complete_path;

        }


        if ($request->hasFile('image')) {
            $newimage = $request->file('image');

            // Define the path where you want to store the uploaded image
            $path = 'images';
            $path2 = 'images/webp';
            $uniqueimagename = rand(1111,9999).time();
            $uniqueimage_original = $uniqueimagename.'.'.$newimage->getClientOriginalExtension();

            $other_format_path  = $newimage->move($path, $uniqueimage_original);
            $manager = new ImageManager(new Driver());
            $image = $manager->read($other_format_path);

            $encoded = $image->toWebp()->save($path2.'/'.$uniqueimagename.'.webp');
            $complete_path = $path2.'/'.$uniqueimagename.'.webp';

            $savecategory->image = $complete_path;

        }


        if ($request->hasFile('meta_image')) {
            $newimage = $request->file('meta_image');

            // Define the path where you want to store the uploaded image
            $path = 'images';
            $path2 = 'images/webp';
            $uniqueimagename = rand(1111,9999).time();
            $uniqueimage_original = $uniqueimagename.'.'.$newimage->getClientOriginalExtension();

            $other_format_path  = $newimage->move($path, $uniqueimage_original);
            $manager = new ImageManager(new Driver());
            $image = $manager->read($other_format_path);

            $encoded = $image->toWebp()->save($path2.'/'.$uniqueimagename.'.webp');
            $complete_path = $path2.'/'.$uniqueimagename.'.webp';

            $savecategory->meta_image = $complete_path;

        }

        if($savecategory->save()){
            return redirect(url('admin/section'));
        }
    }

    public function destroy($id)
    {
//        $delete = Section::where('id', $id)->delete();
        $productdelete = Product::where('brands_id',$id)->get();

        foreach($productdelete as $products){

            $productSize = Product_size::where('product_id',$products->id)->delete();
//            print_r($productSize);die;
            $productdelete = Product::where('brands_id',$id)->delete();
        }

        $delete = Section::where('id', $id)->delete();
//        die;

        if ($delete == 1) {
            $success = true;
            $message = "Deleted";
        } else {
            $success = true;
            $message = "not found";
        }
        return response()->json([
            'success' => $success,
            'message' => $message,
        ]);
    }

    public function change_status(Request $request){
        $category = Section::find($request->id);
        if($request->status == '1'){
            $category->status = '1';

			if($request->id<=2){
			$products = Product::where('section_id', '=', $request->id )->update(['status' => 1]);
			}else{
				$products = Product::where('brands_id', '=', $request->id )->update(['status' => 1]);
			}

        }else{

			if($request->id<=2){
			$products = Product::where('section_id', '=', $request->id )->update(['status' => 0]);
			}else{
				$products = Product::where('brands_id', '=', $request->id )->update(['status' => 0]);
			}

            $category->status = '0';
        }
        $category->save();
        return response()->json(['success'=>' status change successfully.']);
    }

    public function show_on_homet_status(Request $request){
//        print_r($request->all());die;
        $category = Section::find($request->id);
        $category->show_on_homepage = $request->status;

        $category->save();
        return response()->json(['success'=>' status change successfully.']);
    }

    public function uploadCategoryContent(Request $request){
    $file = $request->file('csv_file');
    if ($file) {
        $filename = $file->getClientOriginalName();
        $extension = $file->getClientOriginalExtension(); //Get extension of uploaded file
        $tempPath = $file->getRealPath();
        $fileSize = $file->getSize(); //Get size of uploaded file in bytes
//Check for file extension and size
        $this->checkUploadedFileProperties($extension, $fileSize);
//Where uploaded file will be stored on the server
        $location = 'uploads'; //Created an "uploads" folder for that
// Upload file
        $file->move($location, $filename);
// In case the uploaded file path is to be stored in the database
        $filepath = public_path($location . "/" . $filename);
// Reading file
        $file = fopen($filepath, "r");
        $importData_arr = array(); // Read through the file and store the contents as an array

        $i = 0;
//Read the contents of the uploaded file
        while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
            $num = count($filedata);
// Skip first row (Remove below comment if you want to skip the first row)
            if ($i == 0) {
                $i++;
                continue;
            }
            for ($c = 0; $c < $num; $c++) {
                $importData_arr[$i][] = $filedata[$c];
            }
            $i++;
        }
        fclose($file); //Close after reading
        $j = 0;
        foreach ($importData_arr as $importData) {
            echo "<pre>";
            print_r($importData);
            $id = $importData[0];
            $category_name = $importData[2];
            $slug = $importData[3];
            $parent_id = $importData[4];
            $meta_tag_description = $importData[5];
            $meta_tag_keywords = $importData[6];
            $show_on_homepage = $importData[10];
            $show_on_menu = $importData[11];

//            $j++;
            try {
                $savecategory = new Section;
                $savecategory->id = $id;
                $savecategory->category_name = $category_name;
                $savecategory->slug = $slug;
                $savecategory->parent_id = $parent_id;
                $savecategory->meta_tag_description = $meta_tag_description;
                $savecategory->meta_tag_keywords = $meta_tag_keywords;
                $savecategory->show_on_menu = $show_on_menu;
                $savecategory->show_on_homepage = $show_on_homepage;

                $savecategory->save();
            } catch (\Exception $e) {
                throw $e;
                DB::rollBack();
            }
        }

        return response()->json([
            'message' => "$j records successfully uploaded"
        ]);
    } else {
//no file was uploaded
        throw new \Exception('No file was uploaded', Response::HTTP_BAD_REQUEST);
    }
}
    public function checkUploadedFileProperties($extension, $fileSize)
    {
        $valid_extension = array("csv", "xlsx"); //Only want csv and excel files
        $maxFileSize = 2097152; // Uploaded file size limit is 2mb
        if (in_array(strtolower($extension), $valid_extension)) {
            if ($fileSize <= $maxFileSize) {
            } else {
                throw new \Exception('No file was uploaded', Response::HTTP_REQUEST_ENTITY_TOO_LARGE); //413 error
            }
        } else {
            throw new \Exception('Invalid file extension', Response::HTTP_UNSUPPORTED_MEDIA_TYPE); //415 error
        }
    }

}
